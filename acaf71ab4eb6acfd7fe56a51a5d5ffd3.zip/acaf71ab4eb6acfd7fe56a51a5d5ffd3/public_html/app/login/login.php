<?php
$db = new SQLite3('keys.db');

$username = $_POST['username'] ?? '';
$key = $_POST['key'] ?? '';

if (!$username || !$key) {
    die("Пожалуйста, заполните все поля.");
}

$stmt = $db->prepare('SELECT * FROM users WHERE username = :username AND key = :key');
$stmt->bindValue(':username', $username, SQLITE3_TEXT);
$stmt->bindValue(':key', $key, SQLITE3_TEXT);
$result = $stmt->execute();

if ($result->fetchArray()) {
    // Перенаправляем в нужную папку
    header('Location: /app/index.html');
    exit;
} else {
    echo "Неверное имя или ключ.";
}
?>