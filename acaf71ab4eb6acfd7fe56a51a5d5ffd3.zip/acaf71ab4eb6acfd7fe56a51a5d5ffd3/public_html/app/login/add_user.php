<?php
$db = new SQLite3('keys.db');

$username = $_POST['username'] ?? '';
$key = $_POST['key'] ?? '';

if (!$username || !$key) {
    die("Пожалуйста, заполните все поля.");
}

$stmt = $db->prepare('INSERT INTO users (username, key) VALUES (:username, :key)');
$stmt->bindValue(':username', $username, SQLITE3_TEXT);
$stmt->bindValue(':key', $key, SQLITE3_TEXT);

if ($stmt->execute()) {
    echo "Ученик успешно добавлен!";
} else {
    echo "Ошибка при добавлении ученика.";
}
?>