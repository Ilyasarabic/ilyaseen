var level = "";

function onBookClick(lvl) {

    level += lvl;

    document.getElementById("b-container").style.visibility = "collapse";
    document.getElementById("m-container").style.visibility = "visible";
    document.getElementById("l-container").style.visibility = "collapse";
    document.getElementById("c-container").style.visibility = "collapse";
}

function onModulClick(modul) {

    level += modul;

    document.getElementById("b-container").style.visibility = "collapse";
    document.getElementById("m-container").style.visibility = "collapse";
    document.getElementById("l-container").style.visibility = "visible";
    document.getElementById("c-container").style.visibility = "collapse";
}

function onLessonClick(lesson) {

    level += lesson

    document.getElementById("b-container").style.visibility = "collapse";
    document.getElementById("m-container").style.visibility = "collapse";
    document.getElementById("l-container").style.visibility = "collapse";
    document.getElementById("c-container").style.visibility = "visible";

    localStorage.setItem("lesson", level);
}

function onCardsClick() {

    document.getElementById("b-container").style.visibility = "collapse";
    document.getElementById("m-container").style.visibility = "collapse";
    document.getElementById("l-container").style.visibility = "collapse";
    document.getElementById("c-container").style.visibility = "Collapse";

    localStorage.setItem("lesson", level);

    window.location.href = `./lessons/cards/cards.html`;
}
function onTFClick() {

    document.getElementById("b-container").style.visibility = "collapse";
    document.getElementById("m-container").style.visibility = "collapse";
    document.getElementById("l-container").style.visibility = "collapse";
    document.getElementById("c-container").style.visibility = "Collapse";

    localStorage.setItem("lesson", level);

    window.location.href = `./lessons/tf/tf.html`;
}
function onTestClick() {

    document.getElementById("b-container").style.visibility = "collapse";
    document.getElementById("m-container").style.visibility = "collapse";
    document.getElementById("l-container").style.visibility = "collapse";
    document.getElementById("c-container").style.visibility = "Collapse";

    localStorage.setItem("lesson", level);

    window.location.href = `./lessons/test/test.html`;
}
function onWriteClick() {

    document.getElementById("b-container").style.visibility = "collapse";
    document.getElementById("m-container").style.visibility = "collapse";
    document.getElementById("l-container").style.visibility = "collapse";
    document.getElementById("c-container").style.visibility = "Collapse";

    localStorage.setItem("lesson", level);

    window.location.href = `./lessons/write/write.html`;
}