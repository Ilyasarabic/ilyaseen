console.log(localStorage.getItem("lesson"));

const lessonNumber = localStorage.getItem("lesson");
const lessonData = data[lessonNumber];

const withTashkeel = lessonData.withTashkeel;
const withoutTashkeel = lessonData.withoutTashkeel;
const translation = lessonData.translation;
const images = lessonData.images;

let currentIndex = 0;
let score = 0;
let randomIndex;

let randomIndexes = Array.from({ length: translation.length }, (_, i) => i)
  .sort(() => Math.random() - 0.5);

function updateDisplay() {
  const displayOne = document.getElementById("ar");
  const displayTwo = document.getElementById("ru");
  const displayThree = document.getElementById("img-front");
  const displayFour = document.getElementById("img-back");

  if (currentIndex < randomIndexes.length) {
    randomIndex = randomIndexes[currentIndex];
    displayOne.textContent = withTashkeel[currentIndex];
    displayTwo.textContent = translation[randomIndex];
    displayThree.src = images[currentIndex];
    displayFour.src = images[currentIndex];
  } else {
    displayResults();
  }

  console.log("Random Index:", randomIndex);
  console.log("Current Index:", currentIndex);
}

function displayResults() {
  document.getElementById("tf-ar-container").style.visibility = "collapse";
  document.getElementById("results").style.visibility = "visible";
  document.getElementById("right").textContent = `Верно: ${score}`;
  document.getElementById("wrong").textContent = `Ошибок: ${translation.length - score}`;
}

updateDisplay();

document.getElementById("t-btn").addEventListener("click", () => {
  if (currentIndex < withTashkeel.length) {
    if (translation[randomIndex] === translation[currentIndex]) {
      score++;
    }
    currentIndex++;
    updateDisplay();
  }
});

document.getElementById("f-btn").addEventListener("click", () => {
  if (currentIndex < withTashkeel.length) {
    if (translation[randomIndex] !== translation[currentIndex]) {
      score++;
    }
    currentIndex++;
    updateDisplay();
  }
});