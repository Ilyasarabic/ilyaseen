console.log(localStorage.getItem("lesson"));

const lessonNumber = localStorage.getItem("lesson");
const lessonData = data[lessonNumber];

const withTashkeel = lessonData.withTashkeel;
const withoutTashkeel = lessonData.withoutTashkeel;
const translation = lessonData.translation;
const images = lessonData.images;

let currentIndex = 0;
var score = 0;

function updateDisplay() {
  const display = document.getElementById("ru");
  const displayThree = document.getElementById("img-front");

  display.textContent = translation[currentIndex];
  displayThree.src = images[currentIndex];
}

updateDisplay();

document.getElementById("write-btn").addEventListener("click", () => {
const userAnswer = document.getElementById("answer").value;

  if (currentIndex < translation.length) {
    currentIndex++;
    document.getElementById("answer").value = "";
    updateDisplay(); // Обновляем содержимое
  }

  if (userAnswer === translation[currentIndex - 1]) {
    score++;
  }

  if (currentIndex === translation.length) {
    document.getElementById("write-ar-container").style.visibility = "collapse";
    document.getElementById("results").style.visibility = "visible";
    document.getElementById("right").textContent = `Верно: ${score}`;
    document.getElementById("wrong").textContent = `Ошибок: ${translation.length - score}`;
  }
});