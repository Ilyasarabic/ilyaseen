console.log(localStorage.getItem("lesson"));

const lessonNumber = localStorage.getItem("lesson");
const lessonData = data[lessonNumber];

const withTashkeel = lessonData.withTashkeel;
const withoutTashkeel = lessonData.withoutTashkeel;
const translation = lessonData.translation;
const images = lessonData.images;

let currentIndex = 0;

function updateDisplay() {
  const displayOne = document.getElementById("ar");
  const displayTwo = document.getElementById("ru");
  const displayThree = document.getElementById("img-front");
  const displayFour = document.getElementById("img-back");

  displayOne.textContent = withTashkeel[currentIndex];
  displayTwo.textContent = translation[currentIndex];
  displayThree.src = images[currentIndex];
  displayFour.src = images[currentIndex];
}

updateDisplay();

document.getElementById("next-btn").addEventListener("click", () => {
  if (currentIndex < withTashkeel.length - 1) {
    currentIndex++;
    updateDisplay();
  }
});

document.getElementById("back-btn").addEventListener("click", () => {
  if (currentIndex > 0) {
    currentIndex--;
    updateDisplay();
  }
});

