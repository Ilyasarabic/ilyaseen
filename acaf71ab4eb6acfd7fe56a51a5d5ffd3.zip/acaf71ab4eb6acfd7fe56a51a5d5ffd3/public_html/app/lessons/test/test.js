console.log(localStorage.getItem("lesson"));

const lessonNumber = localStorage.getItem("lesson");
const lessonData = data[lessonNumber];

const withTashkeel = lessonData.withTashkeel;
const withoutTashkeel = lessonData.withoutTashkeel;
const translation = lessonData.translation;
const images = lessonData.images;

let currentIndex = 0;
let score = 0;

function getRandomIndices(correctIndex, total) {
    const indices = new Set();
    indices.add(correctIndex);

    while (indices.size < 4) {
        const randomIndex = Math.floor(Math.random() * total);
        indices.add(randomIndex);
    }

    return Array.from(indices).sort(() => Math.random() - 0.5);
}

function updateDisplay() {
    if (currentIndex >= withTashkeel.length) {
        displayResults();
        return;
    }

    const displayOne = document.getElementById("ar");
    const displayThree = document.getElementById("img-front");
    displayOne.textContent = withTashkeel[currentIndex];
    displayThree.src = images[currentIndex];

    const correctIndex = currentIndex;
    const options = getRandomIndices(correctIndex, translation.length);

    const buttons = [
        document.getElementById("first-btn"),
        document.getElementById("second-btn"),
        document.getElementById("third-btn"),
        document.getElementById("fourth-btn"),
    ];

    options.forEach((index, i) => {
        buttons[i].textContent = translation[index];
        buttons[i].onclick = () => handleAnswer(index === correctIndex);
    });
}

function handleAnswer(isCorrect) {
    if (isCorrect) {
        score++;
    }
    currentIndex++;
    updateDisplay();
}

function displayResults() {
    document.getElementById("test-ru-container").style.visibility = "collapse";
    document.getElementById("results").style.visibility = "visible";
    document.getElementById("right").textContent = `Верно: ${score}`;
    document.getElementById("wrong").textContent = `Ошибок: ${withTashkeel.length - score}`;
}

updateDisplay();